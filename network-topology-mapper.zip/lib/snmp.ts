import snmp from 'net-snmp';
import { Device } from '@/types/network';

// Standard OIDs
const OID_SYS_DESCR = '1.3.6.1.2.1.1.1.0';
const OID_SYS_OBJECT_ID = '1.3.6.1.2.1.1.2.0';
const OID_SYS_NAME = '1.3.6.1.2.1.1.5.0';
const OID_IP_NET_TO_MEDIA_PHYS_ADDRESS = '1.3.6.1.2.1.4.22.1.2'; // ARP Table MACs
const OID_IP_NET_TO_MEDIA_NET_ADDRESS = '1.3.6.1.2.1.4.22.1.3';  // ARP Table IPs

// Basic Vendor mapping based on sysObjectID prefixes (Enterprise Numbers)
// This is a very simplified list. A real app would use a comprehensive database.
const VENDOR_MAP: Record<string, string> = {
  '1.3.6.1.4.1.9': 'Cisco',
  '1.3.6.1.4.1.14988': 'MikroTik',
  '1.3.6.1.4.1.2011': 'Huawei',
  '1.3.6.1.4.1.25506': 'H3C',
  '1.3.6.1.4.1.43': '3Com',
  '1.3.6.1.4.1.11': 'HP',
  '1.3.6.1.4.1.6486': 'Alcatel-Lucent',
  '1.3.6.1.4.1.2636': 'Juniper',
  '1.3.6.1.4.1.8072': 'Net-SNMP (Linux)',
};

/**
 * Attempts to query basic system info via SNMP v2c.
 * @param ip Target IP address
 * @param community SNMP community string (default: 'public')
 * @returns Partial Device object with discovered info, or null if SNMP fails
 */
export async function queryBasicSnmpInfo(ip: string, community: string = 'public'): Promise<Partial<Device> | null> {
  return new Promise((resolve) => {
    const session = snmp.createSession(ip, community, {
      timeout: 1000,
      retries: 1,
      version: snmp.Version2c,
    });

    const oids = [OID_SYS_NAME, OID_SYS_OBJECT_ID, OID_SYS_DESCR];

    session.get(oids, (error, varbinds) => {
      if (error || !varbinds) {
        // SNMP not responding or wrong community
        session.close();
        resolve(null);
        return;
      }

      const info: Partial<Device> = {};

      for (let i = 0; i < varbinds.length; i++) {
        if (snmp.isVarbindError(varbinds[i])) {
          continue;
        }

        const oid = varbinds[i].oid;
        const value = varbinds[i].value;

        if (oid === OID_SYS_NAME && value) {
          info.name = value.toString();
        } else if (oid === OID_SYS_OBJECT_ID && value) {
          info.sysObjectID = value.toString();
          
          // Try to guess vendor and type
          const vendorKey = Object.keys(VENDOR_MAP).find(prefix => info.sysObjectID?.startsWith(prefix));
          if (vendorKey) {
            info.vendor = VENDOR_MAP[vendorKey];
            // Very basic heuristic: if it answers SNMP and has a known enterprise OID, 
            // it's likely infrastructure (switch/router) rather than an end-device.
            info.type = 'switch'; 
          }
        }
      }

      session.close();
      resolve(info);
    });
  });
}

/**
 * Formats a Buffer containing a MAC address into a standard hex string (XX:XX:XX:XX:XX:XX)
 */
function formatMacAddress(buffer: Buffer): string {
  if (!buffer || buffer.length !== 6) return '';
  return Array.from(buffer)
    .map(b => b.toString(16).padStart(2, '0'))
    .join(':')
    .toUpperCase();
}

/**
 * Walks the ARP table (ipNetToMediaTable) to discover connected End-Devices.
 * @param ip Target IP address (usually a router/L3 switch)
 * @param community SNMP community string
 * @returns Array of discovered End-Devices
 */
export async function walkArpTable(ip: string, community: string = 'public'): Promise<Device[]> {
  return new Promise((resolve) => {
    const session = snmp.createSession(ip, community, {
      timeout: 2000,
      retries: 1,
      version: snmp.Version2c,
    });

    const endDevices: Device[] = [];
    const maxRepetitions = 20;

    // We walk the MAC address column of the ARP table
    session.subtree(OID_IP_NET_TO_MEDIA_PHYS_ADDRESS, maxRepetitions, (varbinds) => {
      for (let i = 0; i < varbinds.length; i++) {
        if (snmp.isVarbindError(varbinds[i])) continue;

        const oid = varbinds[i].oid;
        const macBuffer = varbinds[i].value as Buffer;
        
        // The OID for ARP MAC is 1.3.6.1.2.1.4.22.1.2.<ifIndex>.<IP.Address>
        // We extract the IP address from the end of the OID
        const oidParts = oid.split('.');
        const ipParts = oidParts.slice(-4);
        const deviceIp = ipParts.join('.');
        
        const macAddress = formatMacAddress(macBuffer);

        if (macAddress && deviceIp && deviceIp !== '127.0.0.1' && deviceIp !== '0.0.0.0') {
          endDevices.push({
            id: macAddress,
            ip: deviceIp,
            mac: macAddress,
            type: 'end-device',
            status: 'up',
            lastSeen: new Date().toISOString(),
          });
        }
      }
    }, (error) => {
      session.close();
      if (error) {
        console.error(`Error walking ARP table on ${ip}:`, error.message);
      }
      resolve(endDevices);
    });
  });
}
