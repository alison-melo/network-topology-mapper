import IPCIDR from 'ip-cidr';

/**
 * Converts a CIDR string (e.g., "192.168.1.0/24") into an array of IP addresses.
 * @param cidrStr The CIDR notation string.
 * @returns An array of IP addresses.
 */
export function getIpsFromCidr(cidrStr: string): string[] {
  try {
    const cidr = new IPCIDR(cidrStr);
    
    // toArray() returns all IPs in the range, including network and broadcast addresses
    // We usually want to skip the first (network) and last (broadcast) for standard subnets
    const ips = cidr.toArray();
    
    if (ips.length > 2) {
      // Return usable IPs (skip network and broadcast)
      return ips.slice(1, -1);
    }
    
    return ips;
  } catch (error) {
    throw new Error('Invalid CIDR format. Please use format like 192.168.1.0/24');
  }
}
