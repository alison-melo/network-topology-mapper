'use client';

import { useEffect, useRef, useState } from 'react';
import cytoscape from 'cytoscape';
import { Device, TopologyNode, TopologyEdge } from '@/types/network';
import { Download, Maximize2, X, Monitor, Server, Router, SwitchCamera, Share2 } from 'lucide-react';
import jsPDF from 'jspdf';

interface TopologyMapProps {
  devices: Device[];
}

export default function TopologyMap({ devices }: TopologyMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<cytoscape.Core | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);

  useEffect(() => {
    if (!containerRef.current || devices.length === 0) return;

    // Transform devices into Cytoscape elements
    const nodes: cytoscape.ElementDefinition[] = [];
    const edges: cytoscape.ElementDefinition[] = [];

    // Create a central "Cloud/Internet" node
    nodes.push({
      data: { id: 'internet', label: 'Network', type: 'cloud' },
      classes: 'cloud'
    });

    devices.forEach((device) => {
      // Add main device node
      nodes.push({
        data: {
          id: device.id || device.ip,
          label: device.name || device.ip,
          type: device.type,
          ip: device.ip,
          vendor: device.vendor,
          rawDevice: device // Store full device for sidebar
        },
        classes: device.type
      });

      // Connect to internet node (simplified topology)
      edges.push({
        data: {
          id: `edge-internet-${device.id || device.ip}`,
          source: 'internet',
          target: device.id || device.ip,
        }
      });
    });

    // Initialize Cytoscape
    const cy = cytoscape({
      container: containerRef.current,
      elements: [...nodes, ...edges],
      style: [
        {
          selector: 'node',
          style: {
            'label': 'data(label)',
            'text-valign': 'bottom',
            'text-halign': 'center',
            'text-margin-y': 8,
            'font-size': '12px',
            'font-family': 'Inter, sans-serif',
            'color': '#475569',
            'background-color': '#fff',
            'border-width': 2,
            'border-color': '#cbd5e1',
            'width': 40,
            'height': 40,
          }
        },
        {
          selector: 'node.cloud',
          style: {
            'background-color': '#f8fafc',
            'border-color': '#94a3b8',
            'shape': 'ellipse',
            'width': 60,
            'height': 40,
            'font-weight': 'bold'
          }
        },
        {
          selector: 'node.router',
          style: { 'border-color': '#6366f1', 'background-color': '#e0e7ff' }
        },
        {
          selector: 'node.switch',
          style: { 'border-color': '#10b981', 'background-color': '#d1fae5', 'shape': 'round-rectangle' }
        },
        {
          selector: 'node.ap',
          style: { 'border-color': '#f59e0b', 'background-color': '#fef3c7' }
        },
        {
          selector: 'node.end-device',
          style: { 'border-color': '#64748b', 'background-color': '#f1f5f9', 'width': 30, 'height': 30 }
        },
        {
          selector: 'node:selected',
          style: {
            'border-width': 4,
            'border-color': '#3b82f6',
            'background-color': '#bfdbfe'
          }
        },
        {
          selector: 'edge',
          style: {
            'width': 2,
            'line-color': '#cbd5e1',
            'curve-style': 'bezier',
            'target-arrow-shape': 'none'
          }
        }
      ],
      layout: {
        name: 'cose', // Force-directed layout
        idealEdgeLength: 100,
        nodeOverlap: 20,
        refresh: 20,
        fit: true,
        padding: 30,
        randomize: false,
        componentSpacing: 100,
        nodeRepulsion: 400000,
        edgeElasticity: 100,
        nestingFactor: 5,
      },
      userZoomingEnabled: true,
      userPanningEnabled: true,
      boxSelectionEnabled: false,
    });

    // Handle node click
    cy.on('tap', 'node', (evt) => {
      const node = evt.target;
      if (node.data('type') !== 'cloud') {
        setSelectedDevice(node.data('rawDevice'));
      } else {
        setSelectedDevice(null);
      }
    });

    cy.on('tap', (evt) => {
      if (evt.target === cy) {
        setSelectedDevice(null);
      }
    });

    cyRef.current = cy;

    return () => {
      cy.destroy();
    };
  }, [devices]);

  const handleExportPDF = () => {
    if (!cyRef.current) return;
    
    // Get base64 image from cytoscape
    const png64 = cyRef.current.png({ bg: '#ffffff', full: true, scale: 2 });
    
    // Create PDF
    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    });

    // Add title
    pdf.setFontSize(16);
    pdf.text('Network Topology Map', 15, 15);
    pdf.setFontSize(10);
    pdf.setTextColor(100);
    pdf.text(`Generated on: ${new Date().toLocaleString()}`, 15, 22);

    // Add image
    // A4 landscape dimensions: 297 x 210 mm
    // Leave margins
    pdf.addImage(png64, 'PNG', 15, 30, 267, 165);
    
    pdf.save(`network_topology_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  const handleFit = () => {
    if (cyRef.current) {
      cyRef.current.fit();
    }
  };

  if (devices.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Share2 className="w-8 h-8 text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900">No Topology Data</h3>
        <p className="text-slate-500 mt-2">Run a network scan to generate the topology map.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-[600px] relative">
      {/* Toolbar */}
      <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50 z-10">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">Topology Map</h3>
          <p className="text-sm text-slate-500">Interactive network visualization</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleFit}
            className="p-2 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
            title="Fit to screen"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
          <button
            onClick={handleExportPDF}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            <Download className="w-4 h-4" />
            Export PDF
          </button>
        </div>
      </div>

      <div className="flex-1 flex relative">
        {/* Cytoscape Container */}
        <div ref={containerRef} className="flex-1 bg-slate-50/30" />

        {/* Sidebar for Selected Device */}
        {selectedDevice && (
          <div className="w-80 border-l border-slate-200 bg-white p-6 overflow-y-auto shadow-[-4px_0_15px_-3px_rgba(0,0,0,0.05)] absolute right-0 top-0 bottom-0 z-20">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-base font-semibold text-slate-900">Device Details</h4>
              <button 
                onClick={() => setSelectedDevice(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">IP Address</span>
                <p className="mt-1 font-mono text-sm text-slate-900">{selectedDevice.ip}</p>
              </div>
              
              <div>
                <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">MAC Address</span>
                <p className="mt-1 font-mono text-sm text-slate-900">{selectedDevice.mac || 'Unknown'}</p>
              </div>

              <div>
                <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Hostname</span>
                <p className="mt-1 text-sm text-slate-900">{selectedDevice.name || 'Unknown'}</p>
              </div>

              <div>
                <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Vendor</span>
                <p className="mt-1 text-sm text-slate-900">{selectedDevice.vendor || 'Unknown'}</p>
              </div>

              {selectedDevice.endDevices && selectedDevice.endDevices.length > 0 && (
                <div className="pt-4 border-t border-slate-200 mt-6">
                  <span className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-3 block">
                    Connected End-Devices ({selectedDevice.endDevices.length})
                  </span>
                  <ul className="space-y-3">
                    {selectedDevice.endDevices.map((ed, idx) => (
                      <li key={idx} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
                        <Monitor className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                        <div>
                          <p className="text-xs font-mono text-slate-700">{ed.ip}</p>
                          <p className="text-xs font-mono text-slate-500 mt-0.5">{ed.mac}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
