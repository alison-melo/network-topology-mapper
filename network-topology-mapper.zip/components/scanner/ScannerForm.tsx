'use client';

import { useState } from 'react';
import { Play, Square, Loader2, Network, AlertCircle } from 'lucide-react';
import { Device } from '@/types/network';

interface ScannerFormProps {
  onScanStart: () => void;
  onDeviceFound: (device: Device) => void;
  onScanComplete: () => void;
  isScanning: boolean;
}

export default function ScannerForm({ onScanStart, onDeviceFound, onScanComplete, isScanning }: ScannerFormProps) {
  const [cidr, setCidr] = useState('192.168.1.0/24');
  const [error, setError] = useState<string | null>(null);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cidr) return;

    onScanStart();
    setError(null);

    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cidr }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to start scan');
      }

      if (!res.body) throw new Error('No response body');

      const reader = res.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) {
          onScanComplete();
          break;
        }

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n\n');
        
        for (const line of lines) {
          if (line.startsWith('event: done')) {
            onScanComplete();
            break;
          }
          
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data && data.ip) {
                onDeviceFound(data);
              }
            } catch (e) {
              console.error('Error parsing SSE data:', e);
            }
          }
        }
      }
    } catch (err: any) {
      setError(err.message);
      onScanComplete();
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
          <Network className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-slate-900">Network Scanner</h2>
          <p className="text-sm text-slate-500">Discover devices on your network using ICMP Ping Sweep</p>
        </div>
      </div>

      <form onSubmit={handleScan} className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <label htmlFor="cidr" className="sr-only">CIDR Range</label>
          <input
            id="cidr"
            type="text"
            value={cidr}
            onChange={(e) => setCidr(e.target.value)}
            placeholder="e.g., 192.168.1.0/24"
            disabled={isScanning}
            className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 disabled:bg-slate-50 disabled:text-slate-500 outline-none transition-all"
          />
        </div>
        
        <button
          type="submit"
          disabled={isScanning || !cidr}
          className="inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {isScanning ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Scanning...
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              Start Scan
            </>
          )}
        </button>
        
        {isScanning && (
          <button
            type="button"
            onClick={() => window.location.reload()} // Simple abort for now
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-50 text-rose-600 font-medium rounded-lg hover:bg-rose-100 transition-all"
          >
            <Square className="w-4 h-4" />
            Stop
          </button>
        )}
      </form>

      {error && (
        <div className="mt-4 p-4 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 mt-0.5" />
          <p className="text-sm text-rose-800">{error}</p>
        </div>
      )}
    </div>
  );
}
