import { NextRequest } from 'next/server';
import { getIpsFromCidr } from '@/lib/cidr';
import ping from 'ping';
import { Device } from '@/types/network';
import { queryBasicSnmpInfo, walkArpTable } from '@/lib/snmp';

export async function POST(req: NextRequest) {
  try {
    const { cidr } = await req.json();
    
    if (!cidr) {
      return new Response(JSON.stringify({ error: 'CIDR is required' }), { status: 400 });
    }

    const ips = getIpsFromCidr(cidr);

    // Create a ReadableStream to send Server-Sent Events (SSE)
    const stream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        
        // We will ping IPs in batches to speed up the process
        const BATCH_SIZE = 20;
        
        for (let i = 0; i < ips.length; i += BATCH_SIZE) {
          const batch = ips.slice(i, i + BATCH_SIZE);
          
          // Ping all IPs in the batch concurrently
          const promises = batch.map(async (ip) => {
            try {
              // Timeout of 1 second for faster scanning
              const res = await ping.promise.probe(ip, { timeout: 1 });
              
              if (res.alive) {
                let device: Device = {
                  id: ip, // Temporary ID until we get MAC
                  ip: ip,
                  status: 'up',
                  type: 'unknown',
                  lastSeen: new Date().toISOString(),
                };
                
                // Try to get SNMP info
                const snmpInfo = await queryBasicSnmpInfo(ip);
                if (snmpInfo) {
                  device = { ...device, ...snmpInfo };
                  
                  // If it's a switch/router, try to get its ARP table
                  if (device.type === 'switch' || device.type === 'router') {
                    const arpDevices = await walkArpTable(ip);
                    device.endDevices = arpDevices;
                  }
                }
                
                // Send the discovered device to the client
                controller.enqueue(encoder.encode(`data: ${JSON.stringify(device)}\n\n`));
              }
            } catch (err) {
              console.error(`Error pinging ${ip}:`, err);
            }
          });
          
          await Promise.all(promises);
        }
        
        // Signal that the scan is complete
        controller.enqueue(encoder.encode(`event: done\ndata: {}\n\n`));
        controller.close();
      }
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
    
  } catch (error: any) {
    return new Response(JSON.stringify({ error: error.message }), { status: 400 });
  }
}
